clear all
run HW11_1.m
run HW11_2.m
run HW11_3.m
run HW11_4.m
run HW11_5.m
run HW11_6.m