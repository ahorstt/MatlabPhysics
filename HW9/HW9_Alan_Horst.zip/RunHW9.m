clear all
run HW9_1.m
run HW9_2.m
run HW9_3.m
run HW9_5.m