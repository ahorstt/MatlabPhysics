clear
run HW3_1_a.m
run HW3_1_b.m
run HW3_2.m
run HW3_3.m
run HW3_4.m