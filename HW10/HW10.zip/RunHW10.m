clear all
run HW10_1.m
run HW10_2.m
run HW10_3.m