clear
run HW8_1.m
run HW8_2.m
run HW8_3.m