clear
run HW4_1_a.m
run HW4_1_b.m
run HW4_2.m
run HW4_3.m
run HW4_4a.m
run HW4_4b.m
run HW4_5.m