clear all
run HW12_1.m
run HW12_2.m
run HW12_3.m