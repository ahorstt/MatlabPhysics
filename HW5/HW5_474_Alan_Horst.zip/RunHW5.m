clear
run HW5_1a.m
run HW5_1b.m
run HW5_1c.m
run HW5_1d.m
run HW5_1e.m
run HW5_1fi.m
run HW5_1fiii.m