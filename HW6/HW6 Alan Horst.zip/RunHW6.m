clear
run HW6_1.m
run HW6_2.m
run HW6_3.m
run HW6_4.m